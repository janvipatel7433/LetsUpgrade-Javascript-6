
const name = prompt("Enter your name","your name here");
title.innerHTML += name;

const times = document.getElementById("time");
function clock()
{
	let date = new Date();
	let time = date.toLocaleString();
	times.innerText = time;
}
setInterval(clock,1000);






function myFunction()
{
	const attr = document.getElementById("attribute");
	attr.classList.toggle("bgEffect");
}
