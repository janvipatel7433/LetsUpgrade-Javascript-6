



					var color = ["black", "blue", "brown"];

	
					for(let i = 0; i<color.length ; i++)
						{
							function changeColor()
							{
								
								document.body.style.backgroundColor = color[i];
							
							}
							
						}	
						
				
				setInterval(changeColor,2000);

	
	
	